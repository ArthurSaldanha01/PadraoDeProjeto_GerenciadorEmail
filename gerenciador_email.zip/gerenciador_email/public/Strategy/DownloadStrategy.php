<?php
interface DownloadStrategy {
    public function baixar($emailData);
}
?>

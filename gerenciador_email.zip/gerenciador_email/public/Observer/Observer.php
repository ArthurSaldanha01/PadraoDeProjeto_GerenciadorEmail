<?php
interface Observer {
    public function update($eventData);
}
?>

<?php

interface Email {
    public function enviar();
}
?>